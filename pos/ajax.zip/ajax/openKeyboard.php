<?php
shell_exec('start osk');
?>