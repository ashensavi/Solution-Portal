<?php
shell_exec('start calc');
?>